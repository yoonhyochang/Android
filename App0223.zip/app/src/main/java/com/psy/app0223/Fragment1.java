package com.psy.app0223;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Fragment1 extends Fragment {

    ImageView[] dodos = new ImageView[9];
    DoThread[] thread = new DoThread[9];

    TextView tv_time;
    TextView tv_cnt;
    int cnt;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_1,container,false);

        tv_time = view.findViewById(R.id.tv_time);
        tv_cnt = view.findViewById(R.id.tv_cnt);

        // 두더지(ImageView) 9개 findViewByid
        for(int i =0; i<dodos.length;i++){
            int imgID = getResources().getIdentifier("imageView"+(i+1),"id",getContext().getPackageName());
            dodos[i] = view.findViewById(imgID);
            dodos[i].setTag("0");
            thread[i] = new DoThread(dodos[i]);


            thread[i].start();
            TimeThread thread = new TimeThread(tv_cnt);
            thread.start();





            dodos[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (view.getTag().toString().equals("1")){
                        Toast.makeText(getContext(), "잡았다!", Toast.LENGTH_SHORT).show();
                        view.setTag("0");
                        cnt++;
                        tv_time.setText(cnt+"");
                    }else {
                        Toast.makeText(getContext(), "못 잡았다!", Toast.LENGTH_SHORT).show();
                        cnt--;
                        tv_time.setText(cnt+"");
                    }




                }
            });

        }

        return view;
    }

    Handler handler2 = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            TextView obj = (TextView) msg.obj;
            int i =msg.arg1;

            obj.setText(i+"");


        }
    };
    Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);

            ImageView img = (ImageView) msg.obj;
            img.setImageResource(msg.arg1);
            img.setTag(msg.arg2+"");
        }
    };

    class DoThread extends Thread{
        private ImageView dodo; // 이 쓰레드 담당 두더지

        public DoThread(ImageView dodo){
            this.dodo = dodo;
        }

        @Override
        public void run() {

            while (true){
                // 랜덤 시간만큼 내려간 상태 유지
                int offTime = new Random().nextInt(5000)+500;//0.5~5.5 초
                try {
                    Thread.sleep(offTime);

                    Message msg = new Message();
                    msg.obj = dodo;
                    msg.arg1 = R.drawable.on;
                    msg.arg2 = 1;
                    // 핸들러한테 보내줄거임
                    handler.sendMessage(msg);
                    int onTime = new Random().nextInt(1000) +500; //0.5~1.5 초
                    Thread.sleep(onTime);
                    // 한번 보낸 Message 객체는 재활용 X
                    Message msg2 = new Message();
                    msg2.obj = dodo;
                    msg2.arg1 = R.drawable.off;
                    msg2.arg2 =0;
                    handler.sendMessage(msg2);

                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }

            }

        }
    }

    class TimeThread extends Thread{

        // Thread 메소드 실행 순서 (Life Cycle)
        // start -> run -> destroy

        private TextView tv;

        public  TimeThread(TextView tv){
            this.tv = tv;
        }
        @Override
        public void run() {

            for(int i = 30; i >= 0 ; i--){

                Message msg = new Message();

                msg.obj = tv;
                msg.arg1 = i;

                handler2.sendMessage(msg);//위에서 구성한MSg 객체 보내기~


                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }

        }
    }

}


