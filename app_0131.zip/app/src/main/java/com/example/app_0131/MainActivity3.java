package com.example.app_0131;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


// 각 버튼을 눌렀을 때, 이미지가 바뀌는 기능을 구현하기!
//1. "다음" 버튼을 누르면 이미지가 순서대로 넘어간다.
// 2. "이전" 버튼을 누르면 이미지가 역순으로 넘어간다.
//3. 이미지를 무한으로 넘어간다. ex) 1->2->3->1->2->3->...
public class MainActivity3 extends AppCompatActivity {
    ImageView img;

    Button btn_pre, btn_next;

    //이미지를 보관하는 배열생성
    int[]imgArray= {R.drawable.muscle,R.drawable.muscle2,R.drawable.muscle3};
    int pos;//자동으로 0으로 초괴화됨
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        img = findViewById(R.id.img);
        btn_pre = findViewById(R.id.btn_pre);
        btn_next = findViewById(R.id.btn_next);

        //ImageView의 이미지를 변경할 때 사용!
        //R.drawable.파일명
        img.setImageResource(R.drawable.muscle);

        //각 버튼을 눌렀을 때, 이미지가 바뀌도록 구현하시오!
        //현재 이미지 : 파일명1
        //"다음" 버튼클릭 -> 파일명2
        //"이전 "버튼 클릭 -> 피열명3

        btn_pre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              if(pos== 0){
                  pos = imgArray.length-1;
              }else{
                  pos-= 1;
              }

                img.setImageResource(imgArray[pos]);
            }

        });
        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(pos == imgArray.length-1){
                    pos =0;
                }else{
                    pos+= 1;
                }
                img.setImageResource(imgArray[pos]);
            }
        });
    }
}