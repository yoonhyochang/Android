package com.example.app0203;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class ColorPickerActivity extends AppCompatActivity {
    Button btn_red,btn_green,btn_blue;

    private  final static int COLR_PICKER_CODE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_picker);
        btn_red =findViewById(R.id.btn_red);
        btn_green =findViewById(R.id.btn_green);
        btn_blue =findViewById(R.id.btn_blue);


        btn_red.setOnClickListener(v->{
            Intent intent = new Intent();
            intent.putExtra("color","#FD5454");
                            // RESULT_OK 대신 1 이것도 가능
            setResult(1,intent);
            finish();
        });

        btn_green.setOnClickListener(v->{
            Intent intent = new Intent();
            intent.putExtra("color","#99CC00");
            // RESULT_OK 대신 COLR_PICKER_CODE 이것도 가능
            setResult(COLR_PICKER_CODE,intent);
            finish();
        });

        btn_blue.setOnClickListener(v->{
            Intent intent = new Intent();
                                            //효창-> 핵사 컬러만 가능 안드로이드 컬러 오류남
            intent.putExtra("color","FF33B5E5");
            setResult(RESULT_OK,intent);
            finish();
        });
    }
}