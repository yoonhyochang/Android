package com.yhc.app_0209;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    // 바로가기 데이터 만들기!
    // => 데이터 하나에는 제목(String), 주소(String)
    // => DirectVO(valueObject) => 사용자(개발자) 정의 자료형

    // DirectVO 를 저장할 ArrayList 생성
    RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //2. DirectVO 객체 생성해서 ArrayList에 3개 저장~
        // - 제목과 주소는 여러분 하고 싶은대로
        ArrayList<DirectVO> directList = new ArrayList<>();
        //new DirectVO("네이버", "naver.com" 이렇게하면 객체 두개가 저장 된다
        directList.add(new DirectVO("네이버", "https://www.naver.com"));
        directList.add(new DirectVO("유튜브", "https://www.youtube.com"));
        directList.add(new DirectVO("구글", "https://www.google.com"));
        rv = findViewById(R.id.RecyclerView);

        DirectAdapter adapter = new DirectAdapter(directList,getApplicationContext());
        rv.setAdapter(adapter);

        // 리스트 형태로 할건지 그리드 형태로 할건지 빼먹으면 안됨!!!!!!!!!!!
        rv.setLayoutManager(new LinearLayoutManager(this));
    }
}