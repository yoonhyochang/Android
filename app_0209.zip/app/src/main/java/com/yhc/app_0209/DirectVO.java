package com.yhc.app_0209;

public class DirectVO {
    // VO(DTO) 구성요소
    // 1. 필드 - 저장하고 싶은 변수들
    private String title;
    private String address;
    // 2. 생성자 메소드 - 필드 초기화 용도
    public DirectVO(String title, String address) {
        this.title = title;
        this.address = address;
    }
    // 3. get (확인용), set(수정용)

    public String getTitle() {
        return title;
    }

    public String getAddress() {
        return address;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    // 4. toString() - 객체에 저장된 모든 필드들을 문자열로 리턴~


    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("DirectVO{");
        sb.append("title='").append(title).append('\'');
        sb.append(", address='").append(address).append('\'');
        sb.append('}');
        return sb.toString();
        // 결론! String을 + 연산 할 때는(+) 보다 Buffer 쓰는게
        // 메모리 소모도 적고 더 빠르다!
    }
}
