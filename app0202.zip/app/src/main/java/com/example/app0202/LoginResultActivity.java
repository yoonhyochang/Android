package com.example.app0202;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class LoginResultActivity extends AppCompatActivity {
    TextView tv_result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_result);

        tv_result = findViewById(R.id.tv_result);
        // 안드로이드 시스템에 저장된 Intent 객체를 가져오기!
        Intent intent = getIntent();

        String id = intent.getStringExtra("id");
        String pw = intent.getStringExtra("pw");

        //유저가 입력한 id,pw가 일치한지 비교
        if(id.equals("yhc9308")&& pw.equals("gyckd1") ){
            tv_result.setText("로그인 성공");
        }else {
            tv_result.setText("로그인 실패");
        }

    }
}
