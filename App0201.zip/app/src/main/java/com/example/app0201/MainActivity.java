package com.example.app0201;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
// 주사위 App
//1. 버튼을 누르면 주사위 눈이 랜덤으로 출력된다.(Random)
//2. 두 주사위 눈을 비교한다.
//2-1. img > img2 : tv_ueser1에 카운트 +1
//2-2. img <img2 : tv_ueser2 에 카운트 +1
// 2-3 img1 == img2 : Toast 를 이용해서 "무승부!" 알림메시지 출력

    ImageView img1,img2;
    Button btn_shake;
    TextView tv_ueser1,tv_ueser2;

    Random random;
    int[] imgArray= {R.drawable.dice1,R.drawable.dice2,R.drawable.dice3,R.drawable.dice4,
                    R.drawable.dice5,R.drawable.dice6 };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        btn_shake = findViewById(R.id.btn_shake);
        tv_ueser1 = findViewById(R.id.tv_user1);
        tv_ueser2 = findViewById(R.id.tv_user2);

        // 버튼에 클릭이벤트 적용하기!(익명클래스)
        //효창-img1.setImageResource(R.drawable.dice1);
        //효창-img2.setImageResource(R.drawable.dice1);
        btn_shake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                random = new Random();
                // img1,img2에 사용할 랜덤수를 생성하기!
                int num1 = random.nextInt(imgArray.length);
                int num2 = random.nextInt(6);

                img1.setImageResource(imgArray[num1]);
                img2.setImageResource(imgArray[num2]);

                // 두 주사위 눈 비교하기!
                if(num1 > num2){
                    // TextView의 text 속성값을 가져온다.
                    // text값을 정수로 변환한다

                    //setText()는 매개변수를 String타입으로 받을 수 있기 때문에
                    //정수형 변수인 user1을 문자열로 변환하기! (String.valueof())
                    int ueser1 = Integer.parseInt(tv_ueser1.getText().toString());
                    ueser1+=1;
                    tv_ueser1.setText(String.valueOf(ueser1));
                }else if(num1 < num2) {
                    int ueser2 = Integer.parseInt(tv_ueser2.getText().toString());
                    ueser2+=1;
                    tv_ueser2.setText(String.valueOf(ueser2));
                }else{
                    Toast.makeText(MainActivity.this, "무승부!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}